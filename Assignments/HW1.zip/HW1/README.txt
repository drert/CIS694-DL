Assignment 1 CI694 - Deep Learning
Alexander Sukennyk

All parts are completed to the best of my ability. 

Output matches the requested format, graphing available for KMeans result (by changing draw_results to True).

Any adjustable parameters which I have added are near the top of each script.

No issues known. Computational errors have not been extensively tested for and may be present.