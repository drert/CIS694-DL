import torch
from sklearn.cluster import KMeans
import numpy as np
import matplotlib.pyplot as plt

# make fake data by normal distribution (mean, std)
n_data = torch.ones(1000, 2)
x0 = torch.normal(2*n_data, 1)      # class0 x data (tensor), shape=(100, 2)
x1 = torch.normal(-2*n_data, 1)     # class1 x data (tensor), shape=(100, 2)
x2 = torch.normal(-5*n_data, 1)     # class2 x data (tensor), shape=(100, 2)
x3 = torch.normal(5*n_data, 1)      # class3 x data (tensor), shape=(100, 2)
x4 = torch.normal(10*n_data, 1)     # class4 x data (tensor), shape=(100, 2)
x = torch.cat((x0, x1, x2, x3, x4), 0).type(torch.FloatTensor)  # shape (200, 2) FloatTensor = 32-bit floating

################# Do kmeans clustering by calling the sklearn built-in function #################
cluster_num = 5
kmeans = KMeans(n_clusters=cluster_num, random_state=0).fit(x.data.numpy())
print(kmeans.cluster_centers_)

plt.ion()   # something about plotting
pred_y = kmeans.labels_
plt.cla()
plt.scatter(x.data.numpy()[:, 0], x.data.numpy()[:, 1], c=pred_y, s=100, lw=0, cmap='RdYlGn')
plt.ioff()
plt.show()
################# 1 Implement your own kmeans clustering function myKmeans() (40 points) #################

# Write your code here for your own kmeans clustering function
def myKmeans(x, K, max_iteration=1000):
    # write your code here based on the algorithm described in class, and you cannot call other kmeans clustering packages here
    return center, mean_intra_cluster_distance, mean_inter_cluster_distance

################# 2 Optimal K for your own kmeans clustering (10 points) #################

# Write your code for a loop to call your own function myKmeans() by setting cluster_number=K from 2 to 10
# print the ratio of mean_intra_cluster_distance over mean_inter_cluster_distance for each K.
# print the optimal K with minimum ratio

 